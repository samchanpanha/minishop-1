import { Telegraf } from 'telegraf';
import { PrismaClient } from '@prisma/client';

const bot = new Telegraf(process.env.TELEGRAM_BOT_TOKEN!);
const prisma = new PrismaClient({
  datasources: {
    db: {
      url: process.env.DATABASE_URL || 'file:../../db/dev.db'
    }
  }
});

// Bot commands
bot.start((ctx) => {
  ctx.reply('🤖 Welcome to MiniShop Bot!\n\n' +
    'Available commands:\n' +
    '/orders - View recent orders\n' +
    '/order <id> - View specific order\n' +
    '/stats - View order statistics\n' +
    '/help - Show this help message');
});

bot.help((ctx) => {
  ctx.reply('📚 *MiniShop Bot Commands:*\n\n' +
    '/orders - View recent orders\n' +
    '/order <id> - View specific order details\n' +
    '/stats - View order statistics\n' +
    '/help - Show this help message\n\n' +
    'Example: /order 123', {
      parse_mode: 'Markdown'
    });
});

bot.command('orders', async (ctx) => {
  try {
    const orders = await prisma.order.findMany({
      take: 10,
      orderBy: { createdAt: 'desc' },
      include: {
        orderItems: {
          include: { product: true }
        }
      }
    });

    if (orders.length === 0) {
      ctx.reply('📭 No orders found.');
      return;
    }

    let message = '📋 *Recent Orders:*\n\n';
    orders.forEach((order) => {
      message += `📦 #${order.id} - $${order.totalAmount.toFixed(2)}\n`;
      message += `👤 ${order.customerName}\n`;
      message += `📅 ${new Date(order.createdAt).toLocaleDateString()}\n\n`;
    });

    ctx.reply(message, { parse_mode: 'Markdown' });
  } catch (error) {
    console.error('Error fetching orders:', error);
    ctx.reply('❌ Error fetching orders. Please try again.');
  }
});

bot.command('order', async (ctx) => {
  const orderId = parseInt(ctx.message.text.split(' ')[1]);
  
  if (!orderId) {
    ctx.reply('❌ Please provide an order ID.\nExample: /order 123');
    return;
  }

  try {
    const order = await prisma.order.findUnique({
      where: { id: orderId },
      include: {
        orderItems: {
          include: { product: true }
        }
      }
    });

    if (!order) {
      ctx.reply(`❌ Order #${orderId} not found.`);
      return;
    }

    let message = `📦 *Order #${order.id}*\n\n`;
    message += `👤 *Customer:* ${order.customerName}\n`;
    message += `📧 *Email:* ${order.customerEmail}\n`;
    message += `📱 *Phone:* ${order.customerPhone}\n`;
    message += `🏠 *Address:* ${order.shippingAddress}\n`;
    message += `💰 *Total:* $${order.totalAmount.toFixed(2)}\n`;
    message += `📅 *Date:* ${new Date(order.createdAt).toLocaleDateString()}\n\n`;
    message += `🛍️ *Items:*\n`;

    order.orderItems.forEach((item) => {
      message += `• ${item.product.name} x${item.quantity} = $${item.subtotal.toFixed(2)}\n`;
    });

    ctx.reply(message, { parse_mode: 'Markdown' });
  } catch (error) {
    console.error('Error fetching order:', error);
    ctx.reply('❌ Error fetching order. Please try again.');
  }
});

bot.command('stats', async (ctx) => {
  try {
    const totalOrders = await prisma.order.count();
    const orders = await prisma.order.findMany({
      select: { totalAmount: true }
    });
    
    const totalRevenue = orders.reduce((sum, order) => sum + order.totalAmount, 0);
    const averageOrderValue = totalOrders > 0 ? totalRevenue / totalOrders : 0;

    const message = `📊 *MiniShop Statistics*\n\n`;
    message += `📦 Total Orders: ${totalOrders}\n`;
    message += `💰 Total Revenue: $${totalRevenue.toFixed(2)}\n`;
    message += `📈 Average Order Value: $${averageOrderValue.toFixed(2)}\n`;

    ctx.reply(message, { parse_mode: 'Markdown' });
  } catch (error) {
    console.error('Error fetching stats:', error);
    ctx.reply('❌ Error fetching statistics. Please try again.');
  }
});

// Handle unknown commands
bot.on('message', (ctx) => {
  if (!ctx.message.text?.startsWith('/')) {
    ctx.reply('🤖 Use /help to see available commands.');
  }
});

// Start the bot
const PORT = process.env.PORT || 3001;
bot.launch({
  telegram: {
    webhook: {
      domain: process.env.WEBHOOK_DOMAIN,
      hookPath: `/webhook/${process.env.TELEGRAM_BOT_TOKEN}`,
      port: PORT
    }
  }
}).then(() => {
  console.log(`Telegram bot started on port ${PORT}`);
}).catch((error) => {
  console.error('Failed to start Telegram bot:', error);
});

// Enable graceful stop
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));