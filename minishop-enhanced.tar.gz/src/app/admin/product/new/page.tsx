'use client';

import ProductForm from '../[id]/page';

export default function NewProduct() {
  return <ProductForm />;
}